"""
synthesize.py
Phase 3: reads every weekly JSON report across the month and produces
cross-project trend data — RAG trajectory per project, recurring blockers,
budget trend, and sentiment trend — instead of just re-summarizing each
project in isolation. This structured output feeds the executive deck.

Design note (fixed after review): the deck used to have its interpretive
sentences ("Alpha's budget burn climbed to 114%...") hardcoded directly in
build_deck.js, so re-running the pipeline on different data would still
show the old text. This module now detects the underlying facts (which
project is declining, which blockers recur, whether sentiment led status
changes, which project needs the spotlight) as structured data, and
reasoning.generate_portfolio_narrative() turns those facts into prose.
Re-run this against different input data and the deck's story changes with it.
"""
import json
import glob
import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))
import reasoning  # noqa: E402  (reuses the pluggable Claude-API / offline-fallback pattern)

RAG_NUM = {"Green": 2, "Amber": 1, "Red": 0}


def load_all_reports(outputs_dir):
    reports = defaultdict(list)  # project_name -> [report, ...] sorted by week
    for week_dir in sorted(glob.glob(os.path.join(outputs_dir, "week*"))):
        for f in sorted(glob.glob(os.path.join(week_dir, "*.json"))):
            with open(f) as fh:
                r = json.load(fh)
            reports[r["project_name"]].append(r)
    for proj in reports:
        reports[proj].sort(key=lambda r: r["week_ending"])
    return reports


def _categorize_blocker(text):
    """Loose keyword categorization so 'recurring pattern' detection isn't
    limited to identical blocker strings across projects — two projects
    hitting *different* vendor issues is still the same risk category."""
    t = text.lower()
    if any(k in t for k in ["vendor", "third party", "third-party", "external"]):
        return "vendor/third-party dependency"
    if any(k in t for k in ["resourc", "owner not", "unassigned", "no owner", "staffing"]):
        return "resourcing/ownership gap"
    return None


def _detect_facts(reports):
    """Pulls out the underlying facts that matter for a portfolio narrative,
    from the raw week-over-week data. No prose here — just facts + numbers."""
    all_blockers = defaultdict(int)
    blocker_projects = defaultdict(set)
    category_projects = defaultdict(set)
    overspend_events = []
    sentiment_negative_count = 0
    sentiment_lead_events = []
    projects_declining, projects_improving, projects_stable_red = [], [], []
    project_facts = {}

    for proj, weekly in reports.items():
        trajectory = [w["overall_status"] for w in weekly]
        week_endings = [w["week_ending"] for w in weekly]
        rag_nums = [RAG_NUM[s] for s in trajectory]
        first, last = rag_nums[0], rag_nums[-1]

        trend = "stable"
        if last < first:
            trend = "declining"
            projects_declining.append(proj)
        elif last > first:
            trend = "improving"
            projects_improving.append(proj)
        elif last == 0:
            projects_stable_red.append(proj)

        neg_week_idx, red_week_idx = None, None
        for i, w in enumerate(weekly):
            for b in w["raw_metrics"].get("blockers", {}).get("items", []):
                key = b.split(" - ")[0].split(" (")[0].strip()
                all_blockers[key] += 1
                blocker_projects[key].add(proj)
                category = _categorize_blocker(b)
                if category:
                    category_projects[category].add(proj)
            if w["raw_metrics"].get("sentiment", {}).get("label") == "negative":
                sentiment_negative_count += 1
                if neg_week_idx is None:
                    neg_week_idx = i
            budget = w["raw_metrics"].get("budget", {})
            if budget.get("burn_ratio") and budget["burn_ratio"] > 1.1:
                overspend_events.append({
                    "project": proj, "week_ending": w["week_ending"],
                    "burn_ratio": budget["burn_ratio"], "status_that_week": w["overall_status"],
                })
            if w["overall_status"] == "Red" and red_week_idx is None:
                red_week_idx = i

        if neg_week_idx is not None and red_week_idx is not None and neg_week_idx < red_week_idx:
            sentiment_lead_events.append({
                "project": proj,
                "lead_weeks": red_week_idx - neg_week_idx,
                "negative_week": week_endings[neg_week_idx],
                "red_week": week_endings[red_week_idx],
            })

        project_facts[proj] = {
            "trajectory": trajectory,
            "week_endings": week_endings,
            "trend": trend,
            "latest_status": trajectory[-1],
            "latest_narrative": weekly[-1]["narrative"],
            "latest_reasons": weekly[-1]["dimension_reasons"],
            "latest_dimension_labels": weekly[-1]["dimension_status"],
            "recommended_action": weekly[-1]["narrative"].split("Recommended action:")[-1].strip().lstrip("*").strip(),
        }

    recurring_blockers = {
        k: {"count": v, "projects": sorted(blocker_projects[k])}
        for k, v in all_blockers.items() if v >= 2
    }

    # Spotlight = the project needing the most executive attention: prefer
    # currently Red, else the most-declined trend, else just the first Amber.
    red_projects = [p for p, f in project_facts.items() if f["latest_status"] == "Red"]
    if red_projects:
        spotlight = red_projects[0]
    else:
        declining = [p for p, f in project_facts.items() if f["trend"] == "declining"]
        spotlight = declining[0] if declining else next(iter(project_facts), None)

    return {
        "project_facts": project_facts,
        "projects_declining": projects_declining,
        "projects_improving": projects_improving,
        "projects_stable_red": projects_stable_red,
        "recurring_blockers": recurring_blockers,
        "category_projects": {k: sorted(v) for k, v in category_projects.items()},
        "overspend_events": overspend_events,
        "sentiment_negative_weeks": sentiment_negative_count,
        "sentiment_lead_events": sentiment_lead_events,
        "spotlight_project": spotlight,
        "total_projects": len(reports),
        "current_rag_mix": {
            status: sum(1 for f in project_facts.values() if f["latest_status"] == status)
            for status in ["Red", "Amber", "Green"]
        },
    }


def synthesize(reports):
    facts = _detect_facts(reports)

    summary = {
        "projects": facts["project_facts"],
        "portfolio": {
            "total_projects": facts["total_projects"],
            "projects_declining": facts["projects_declining"],
            "projects_improving": facts["projects_improving"],
            "projects_stable_red": facts["projects_stable_red"],
            "recurring_blockers": facts["recurring_blockers"],
            "overspending_instances": facts["overspend_events"],
            "weeks_with_negative_sentiment": facts["sentiment_negative_weeks"],
            "current_rag_mix": facts["current_rag_mix"],
        },
    }

    # This is the piece that used to be hardcoded prose in build_deck.js.
    # generate_portfolio_narrative follows the same pluggable pattern as the
    # weekly agent's reasoning.py: real Claude API call if a key is set,
    # deterministic templating (built from these exact facts/numbers) otherwise.
    summary["deck"] = reasoning.generate_portfolio_narrative(facts)
    return summary


if __name__ == "__main__":
    # --demo reads outputs/weekly_demo/ (the synthetic 4-week trend dataset,
    # see agent/run_trend_demo.py) and writes demo_summary.json instead of
    # touching the real client monthly_summary.json. Same code path either
    # way — only the input/output paths differ.
    is_demo = "--demo" in sys.argv
    weekly_dirname = "weekly_demo" if is_demo else "weekly"
    out_filename = "demo_summary.json" if is_demo else "monthly_summary.json"

    outputs_dir = os.path.join(os.path.dirname(__file__), "..", "outputs", weekly_dirname)
    reports = load_all_reports(outputs_dir)
    summary = synthesize(reports)
    out_path = os.path.join(os.path.dirname(__file__), out_filename)
    with open(out_path, "w") as f:
        json.dump(summary, f, indent=2, default=str)
    print(f"Wrote {out_path}")
    print(json.dumps(summary["portfolio"], indent=2, default=str))
